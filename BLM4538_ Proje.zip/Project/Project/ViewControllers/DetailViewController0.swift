//
//  DeViewController.swift
//  Project
//
//  Created by Ali Fixed on 12/03/2022.
//

import UIKit
import SideMenuSwift
import FSPagerView

class DetailViewController0: UITableViewController {
    
    var placeholderData = ["22.12. 2021",
                            "22.12. 2021",
                            "22.12. 2021",
                            "22.12. 2021",
                            "22.12. 2021",
                            "22.12. 2021", ""]
    
    var detailsData = [
        "Doktora Yeterlik Sinavi Basvuru Tarihleri ve Yazili ve Sözlü Sinav",
                       "Yüksek Lisans Seminer Duyurusu (Gizem Eser Erdek)", "Doktora Seminer Duyurusu - Adan Sahin",
        "AI JET BiGG Hizlandirma Program Tanitimi ve Girisimcilik Atölyesi",
        "COM2041 Dersleri Hakkinda",
        "Yüksek Lisans Seminer Duyurusu (Gizem Eser Erdek)",
        ""]
    var sectionName = "DUYURULAR"
    
    @IBOutlet weak var backwardButton: UIButton!
    @IBOutlet weak var forwardButton: UIButton!
    @IBOutlet weak var pagerView: FSPagerView! {
        didSet {
            self.pagerView.register(FSPagerViewCell.self, forCellWithReuseIdentifier: "cell")
            self.pagerView.itemSize = FSPagerView.automaticSize
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SideMenuController.preferences.basic.menuWidth = 240
        SideMenuController.preferences.basic.position = .above
        SideMenuController.preferences.basic.direction = .right
        SideMenuController.preferences.basic.enablePanGesture = true
        SideMenuController.preferences.basic.supportedOrientations = .portrait
        SideMenuController.preferences.basic.shouldRespectLanguageDirection = true
        pagerView.bringSubviewToFront(backwardButton)
        pagerView.bringSubviewToFront(forwardButton)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        fitTableHeaderView()
        fitTableFooterView()
    }
    
    
    func fitTableHeaderView() {
        guard let headerView = tableView.tableHeaderView else {
            return
        }
        let size = headerView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize)
        if headerView.frame.size.height != size.height {
            headerView.frame.size.height = size.height
            tableView.tableHeaderView = headerView
            tableView.layoutIfNeeded()
        }
    }

    func fitTableFooterView() {
        guard let footerView = tableView.tableFooterView else {
            return
        }
        let size = footerView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize)
        if footerView.frame.size.height != size.height {
            footerView.frame.size.height = size.height
            tableView.tableFooterView = footerView
            tableView.layoutIfNeeded()
        }
    }
    
    @IBAction func showSideMenu(_ sender: UITapGestureRecognizer) {
        sideMenuController?.revealMenu()
    }
    
    @IBAction func previousImage(_ sender: UIButton) {
        let prevIndex = pagerView.currentIndex > 0 ? pagerView.currentIndex - 1 : numberOfItems(in:self.pagerView) - 1
        pagerView.scrollToItem(at: prevIndex, animated: true)
    }
    
    @IBAction func nextImage(_ sender: UIButton) {
        let nextIndex = pagerView.currentIndex + 1 < numberOfItems(in:self.pagerView) ? pagerView.currentIndex + 1 : 0
        pagerView.scrollToItem(at: nextIndex, animated: true)
    }
    
    @IBAction func btn1(_ sender: UIButton) {
        //DUYURULAR
    }
    
    @IBAction func btn2(_ sender: UIButton) {
        //SEÇKİLER
        placeholderData = ["16-03-2022", "22-02-2022", "04-10-2021", "23-09-2021", "26-08-2021", "17-08-2021", "17-08-2021"]
        detailsData = ["Stajla İlgili Önemli Duyuru", "Staj Hakkında Genel Bilgiler", "Staj Rapor Teslimi Hakkında!", "Yılı UYUM Etkinlikleri HK.", "Yaz Okulu Final Programı", "Aday Öğrencilerimiz için Bölüm Başkanının mesaji", "Aday Öğrencilerin Dikkatine"]
        sectionName = "SEÇKİLER"
        tableView.reloadData()
        
    }
    
    @IBAction func btn3(_ sender: UIButton) {
        //ETKİnLİKLER
        placeholderData = ["18-10-2021", "28-09-2021", "23-09-2021", "21-09-2021", "14-06-2021", "23-12-2020", "23-09-2020"]
        detailsData = ["TURKCELL TEKNOLOJİ Etkinliği", "Yılı UYUM Etkinlikleri HK.", "2021-2022 Uyum Programı Hakkında", " Bitirme Projesi Sunum Programı", "CVPR'2021 İşaret Dili Tanıma Yarışması", "TELEGRAF Haberleşme Bilgi Sistemi", "Bölüm Başkanından Hoş Geldiniz Mesajı Hakkında"]
        sectionName = "ETKİnLİKLER"
        tableView.reloadData()
    }
    
    @IBAction func btn4(_ sender: UIButton) {
        //OBS
        placeholderData = ["", ""]
        detailsData = ["", ""]
        sectionName = "OBS"
        tableView.reloadData()
    }
    
    @IBAction func btn5(_ sender: UIButton) {
        //AKADEMİK TAKVİM
        placeholderData = ["", ""]
        detailsData = ["", ""]
        sectionName = "AKADEMİK TAKVİM"
        tableView.reloadData()
    }
    
    @IBAction func btn6(_ sender: UIButton) {
        // DERS PROGRAMI
        placeholderData = ["", ""]
        detailsData = ["LİSANS DERS PROGRAMI", "LİSANSÜSTÜ DERS PROGRAMI"]
        sectionName = "DERS PROGRAMI"
        tableView.reloadData()
    }
    
    @IBAction func btn7(_ sender: UIButton) {
        // SINAV PROGRAMI
        placeholderData = ["", "", "", "", ""]
        detailsData = ["GÜZ BÜTÜNLEME SINAV PROGRAMI", "LİSANS VİZE PROGRAMI", "LİSANSÜSTÜ VİZE PROGRAMI", "LİSANS FİNAL PROGRAMI", "LİSANSÜSTÜ FİNAL PROGRAM"]
        sectionName = "SINAV PROGRAMI"
        tableView.reloadData()
    }
}

extension DetailViewController0 {
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return placeholderData.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell") else {
            return UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        }
            return cell
        }()
            
        cell.textLabel?.text = placeholderData[indexPath.row]
        cell.detailTextLabel?.text = detailsData[indexPath.row]
        cell.textLabel?.font = .systemFont(ofSize: 15)
        cell.textLabel?.textColor = .white
        cell.detailTextLabel?.textColor = .white
        cell.backgroundColor = .clear
            
        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sectionName
    }
    
}

extension DetailViewController0: FSPagerViewDataSource {
    
    func numberOfItems(in pagerView: FSPagerView) -> Int {
        return placeholderData.count
    }
    
    func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "cell", at: index)
        switch index {
        case 0: cell.imageView?.image = UIImage(named: "anitkabir_ziyareti-scaled")
        case 1: cell.imageView?.image = UIImage(named: "elektrikli_arac_etkinlik")
        case 2: cell.imageView?.image = UIImage(named: "Fakulte-Birincisi-Elifnur-ACAR")
        case 3: cell.imageView?.image = UIImage(named: "uzaktan_jeofizik_bilgisayar1200x583")
        case 4: cell.imageView?.image = UIImage(named: "dis_kapidan_foto")
        default: break
        }
        return cell
    }
    
}



