//
//  ViewController.swift
//  Project
//
//  Created by Ali Fixed on 12/03/2022.
//

import UIKit

class ViewController: UITableViewController {

    let placeholderData = ["ANASAYFA",
                            "ADAY ÖGRENCI",
                            "LiSANS",
                            "LISANSÚSTU",
                            "ARASTIRMA",
                            "PERSONEL",
                            "AKREDITASYON",
                            "HAKKIMIZDA",
                            "GIKIS"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.backgroundView = {
            let imageView = UIImageView(image: UIImage(systemName: "globe"))
            imageView.backgroundColor = .systemBlue
            imageView.tintColor = .blue.withAlphaComponent(0.1)
            return imageView
        }()
    }

}

extension ViewController {
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 8
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell = {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell") else {
            return UITableViewCell(style: .default, reuseIdentifier: "cell")
        }
            return cell
        }()
            
        cell.textLabel?.text = "* \(placeholderData[indexPath.row])"
        cell.textLabel?.font = .boldSystemFont(ofSize: 25)
        cell.textLabel?.textColor = .white
        cell.backgroundColor = .clear
            
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        switch indexPath.row {
        case 0:
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let detailVC = storyBoard.instantiateViewController(withIdentifier: "DetailVC")
            self.navigationController?.pushViewController(detailVC, animated: true)
        case 1:
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let detailVC = storyBoard.instantiateViewController(withIdentifier: "DetailViewController1")
            self.navigationController?.pushViewController(detailVC, animated: true)
        case 2:
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let detailVC = storyBoard.instantiateViewController(withIdentifier: "DetailViewController2")
            self.navigationController?.pushViewController(detailVC, animated: true)
        case 3:
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let detailVC = storyBoard.instantiateViewController(withIdentifier: "DetailViewController3")
            self.navigationController?.pushViewController(detailVC, animated: true)
        case 4:
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let detailVC = storyBoard.instantiateViewController(withIdentifier: "DetailViewController4")
            self.navigationController?.pushViewController(detailVC, animated: true)
        case 5:
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let detailVC = storyBoard.instantiateViewController(withIdentifier: "DetailViewController5")
            self.navigationController?.pushViewController(detailVC, animated: true)
        case 6:
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let detailVC = storyBoard.instantiateViewController(withIdentifier: "DetailViewController6")
            self.navigationController?.pushViewController(detailVC, animated: true)
        case 7:
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let detailVC = storyBoard.instantiateViewController(withIdentifier: "DetailViewController7")
            self.navigationController?.pushViewController(detailVC, animated: true)
        default:
            break
        }
    }
    
}
